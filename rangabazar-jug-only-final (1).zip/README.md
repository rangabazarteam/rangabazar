# Rangabazar.com

Premium single-product storefront for the Rangabazar Stainless Steel Water Jug. Built with HTML5, CSS3 and vanilla JavaScript; no build step or dependencies are required.

## Main files

- `index.html` — homepage with the Featured from Rangamati video showcase and separate jug product section.
- `assets/css/style.css` — responsive design and visual styling.
- `assets/js/main.js` — mobile navigation, current year and video playback handling.
- `assets/products/stainless-jug.mp4` — original jug showcase video.
- `assets/products/stainless-jug-poster.jpg` — original jug photograph and video poster.
- `assets/logo.png` — Rangabazar logo.
- `privacy.html`, `terms.html`, `returns.html`, `404.html` — retained policy and error pages.
- `CNAME`, `.nojekyll`, `robots.txt`, `sitemap.xml` — GitHub Pages configuration.

## Product and ordering

The displayed starting price is ৳৯৫০. Final pricing varies by size and design; customers are directed to Facebook Messenger for a customized quote:
https://m.me/rangabazarofficial

## Publish on GitHub Pages

1. Copy the contents of this folder into the root of the GitHub repository.
2. In **Settings → Pages**, select deployment from branch `main`, folder `/ (root)`.
3. Keep the custom domain `rangabazar.com` and enable HTTPS.

The site is static and requires no build command.
