/* Rangabazar.com — lightweight single-product storefront interactions */
(function () {
  'use strict';
  var menuBtn = document.getElementById('menu-btn');
  var nav = document.getElementById('primary-nav');

  function setNav(open) {
    if (!menuBtn || !nav) return;
    nav.classList.toggle('is-open', open);
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }

  if (menuBtn && nav) {
    menuBtn.addEventListener('click', function () {
      setNav(!nav.classList.contains('is-open'));
    });
    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () { setNav(false); });
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setNav(false);
    });
  }

  var year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  // Autoplay can be restricted by a browser/device. Keep the video muted and
  // attempt playback without interrupting the rest of the storefront.
  var video = document.querySelector('.jug-video');
  if (video) {
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    var playback = video.play();
    if (playback && typeof playback.catch === 'function') playback.catch(function () {});
  }
}());
